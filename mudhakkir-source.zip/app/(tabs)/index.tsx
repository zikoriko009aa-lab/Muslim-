import { Ionicons } from "@expo/vector-icons";
import { useCallback, useEffect, useState } from "react";
import {
  ActivityIndicator,
  Alert,
  ScrollView,
  StyleSheet,
  Switch,
  Text,
  TouchableOpacity,
  View,
} from "react-native";
import { StatusBar } from "expo-status-bar";

import { ScreenContainer } from "@/components/screen-container";
import {
  cancelReminder,
  isReminderEnabled,
  scheduleReminder,
} from "@/lib/reminder-notifications";

export default function HomeScreen() {
  const [enabled, setEnabled] = useState(false);
  const [busy, setBusy] = useState(true);
  const [changing, setChanging] = useState(false);

  useEffect(() => {
    let mounted = true;
    void isReminderEnabled()
      .then((value) => {
        if (mounted) setEnabled(value);
      })
      .finally(() => {
        if (mounted) setBusy(false);
      });

    return () => {
      mounted = false;
    };
  }, []);

  const toggleReminder = useCallback(async () => {
    if (changing) return;

    setChanging(true);
    try {
      if (enabled) {
        await cancelReminder();
        setEnabled(false);
      } else {
        await scheduleReminder();
        setEnabled(true);
      }
    } catch (error) {
      const message =
        error instanceof Error ? error.message : "حدث خطأ غير متوقع.";
      Alert.alert("تعذر تغيير التذكير", message);
    } finally {
      setChanging(false);
    }
  }, [changing, enabled]);

  return (
    <ScreenContainer
      edges={["top", "left", "right", "bottom"]}
      containerClassName="bg-[#F8F6F0]"
      safeAreaClassName="bg-[#F8F6F0]"
    >
      <StatusBar style="dark" />
      <ScrollView
        contentContainerStyle={styles.content}
        showsVerticalScrollIndicator={false}
      >
        <View style={styles.header}>
          <View>
            <Text style={styles.eyebrow}>وَقْتٌ لِذِكْرِ الله</Text>
            <Text style={styles.title}>مُذَكِّر</Text>
          </View>
          <View style={styles.headerIcon}>
            <Ionicons name="notifications-outline" size={23} color="#2F6B58" />
          </View>
        </View>

        <View style={styles.heroCard}>
          <View style={styles.moonGlow}>
            <Ionicons name="moon-outline" size={46} color="#F3D38B" />
          </View>
          <Text style={styles.heroTitle}>لا تنسى ذكر الله</Text>
          <Text style={styles.heroSubtitle}>
            تذكير صوتي لطيف يرافق يومك كل خمس دقائق
          </Text>
          <View style={styles.frequencyPill}>
            <Ionicons name="time-outline" size={16} color="#2F6B58" />
            <Text style={styles.frequencyText}>كل 5 دقائق</Text>
          </View>
        </View>

        <View style={styles.statusCard}>
          <View style={styles.statusCopy}>
            <View style={styles.statusHeadingRow}>
              <View style={[styles.statusDot, enabled && styles.statusDotOn]} />
              <Text style={styles.statusTitle}>
                {enabled ? "التذكير يعمل" : "التذكير متوقف"}
              </Text>
            </View>
            <Text style={styles.statusDescription}>
              {enabled
                ? "سيصل إشعار بصوت الذكر حتى بعد إغلاق التطبيق."
                : "فعّل التذكير ليبدأ أول إشعار بعد خمس دقائق."}
            </Text>
          </View>
          {busy ? (
            <ActivityIndicator color="#2F6B58" />
          ) : (
            <Switch
              value={enabled}
              onValueChange={toggleReminder}
              disabled={changing}
              trackColor={{ false: "#D8D7D0", true: "#9BC8B2" }}
              thumbColor={enabled ? "#2F6B58" : "#FFFFFF"}
              ios_backgroundColor="#D8D7D0"
              accessibilityRole="switch"
              accessibilityLabel="تشغيل تذكير الذكر كل خمس دقائق"
            />
          )}
        </View>

        <TouchableOpacity
          activeOpacity={0.88}
          onPress={toggleReminder}
          disabled={busy || changing}
          style={[styles.primaryButton, enabled && styles.secondaryButton]}
          accessibilityRole="button"
        >
          {changing ? (
            <ActivityIndicator color={enabled ? "#2F6B58" : "#FFFFFF"} />
          ) : (
            <Ionicons
              name={enabled ? "pause-circle-outline" : "play-circle-outline"}
              size={22}
              color={enabled ? "#2F6B58" : "#FFFFFF"}
            />
          )}
          <Text
            style={[
              styles.primaryButtonText,
              enabled && styles.secondaryButtonText,
            ]}
          >
            {enabled ? "إيقاف التذكير" : "تشغيل التذكير"}
          </Text>
        </TouchableOpacity>

        <View style={styles.infoBlock}>
          <View style={styles.infoIcon}>
            <Ionicons name="volume-high-outline" size={19} color="#A87524" />
          </View>
          <View style={styles.infoCopy}>
            <Text style={styles.infoTitle}>صوت عربي مرفق</Text>
            <Text style={styles.infoText}>
              يستخدم التطبيق صوتًا هادئًا مع إشعار Android. قد يتأخر التنبيه
              قليلًا إذا فعّل الهاتف وضع توفير الطاقة.
            </Text>
          </View>
        </View>

        <Text style={styles.footerText}>
          الإشعارات محلية على جهازك ولا تحتاج إلى إنترنت.
        </Text>
      </ScrollView>
    </ScreenContainer>
  );
}

const styles = StyleSheet.create({
  content: {
    flexGrow: 1,
    paddingHorizontal: 22,
    paddingTop: 18,
    paddingBottom: 34,
  },
  header: {
    alignItems: "center",
    flexDirection: "row-reverse",
    justifyContent: "space-between",
    marginBottom: 28,
  },
  eyebrow: {
    color: "#8B8C82",
    fontSize: 12,
    fontWeight: "700",
    letterSpacing: 1.2,
    textAlign: "right",
  },
  title: {
    color: "#1E3D32",
    fontSize: 34,
    fontWeight: "800",
    marginTop: 2,
    textAlign: "right",
  },
  headerIcon: {
    alignItems: "center",
    backgroundColor: "#E4F0E7",
    borderRadius: 18,
    height: 48,
    justifyContent: "center",
    width: 48,
  },
  heroCard: {
    alignItems: "center",
    backgroundColor: "#245444",
    borderRadius: 30,
    elevation: 6,
    marginBottom: 18,
    paddingHorizontal: 24,
    paddingVertical: 30,
    shadowColor: "#1B4031",
    shadowOffset: { width: 0, height: 8 },
    shadowOpacity: 0.16,
    shadowRadius: 18,
  },
  moonGlow: {
    alignItems: "center",
    backgroundColor: "#356B57",
    borderRadius: 44,
    height: 88,
    justifyContent: "center",
    marginBottom: 20,
    width: 88,
  },
  heroTitle: {
    color: "#FFFDF5",
    fontSize: 25,
    fontWeight: "800",
    textAlign: "center",
  },
  heroSubtitle: {
    color: "#CFE3D2",
    fontSize: 14,
    lineHeight: 23,
    marginTop: 10,
    textAlign: "center",
  },
  frequencyPill: {
    alignItems: "center",
    backgroundColor: "#F7EAC4",
    borderRadius: 20,
    flexDirection: "row",
    gap: 7,
    marginTop: 22,
    paddingHorizontal: 15,
    paddingVertical: 9,
  },
  frequencyText: {
    color: "#2F6B58",
    fontSize: 13,
    fontWeight: "800",
  },
  statusCard: {
    alignItems: "center",
    backgroundColor: "#FFFFFF",
    borderColor: "#E9E6DC",
    borderRadius: 22,
    borderWidth: 1,
    flexDirection: "row-reverse",
    justifyContent: "space-between",
    marginBottom: 14,
    paddingHorizontal: 18,
    paddingVertical: 17,
  },
  statusCopy: {
    flex: 1,
    paddingLeft: 14,
  },
  statusHeadingRow: {
    alignItems: "center",
    flexDirection: "row-reverse",
    gap: 8,
  },
  statusDot: {
    backgroundColor: "#B3B4AD",
    borderRadius: 5,
    height: 10,
    width: 10,
  },
  statusDotOn: {
    backgroundColor: "#38A169",
  },
  statusTitle: {
    color: "#25372F",
    fontSize: 16,
    fontWeight: "800",
    textAlign: "right",
  },
  statusDescription: {
    color: "#858A83",
    fontSize: 12,
    lineHeight: 19,
    marginTop: 5,
    textAlign: "right",
  },
  primaryButton: {
    alignItems: "center",
    backgroundColor: "#2F6B58",
    borderRadius: 18,
    flexDirection: "row-reverse",
    gap: 9,
    justifyContent: "center",
    minHeight: 57,
    shadowColor: "#2F6B58",
    shadowOffset: { width: 0, height: 5 },
    shadowOpacity: 0.2,
    shadowRadius: 10,
  },
  primaryButtonText: {
    color: "#FFFFFF",
    fontSize: 16,
    fontWeight: "800",
  },
  secondaryButton: {
    backgroundColor: "#E4F0E7",
    shadowOpacity: 0,
  },
  secondaryButtonText: {
    color: "#2F6B58",
  },
  infoBlock: {
    alignItems: "flex-start",
    backgroundColor: "#FFF8E9",
    borderColor: "#F2E5C2",
    borderRadius: 20,
    borderWidth: 1,
    flexDirection: "row-reverse",
    gap: 12,
    marginTop: 20,
    padding: 16,
  },
  infoIcon: {
    alignItems: "center",
    backgroundColor: "#F8EBC8",
    borderRadius: 14,
    height: 37,
    justifyContent: "center",
    width: 37,
  },
  infoCopy: {
    flex: 1,
  },
  infoTitle: {
    color: "#7F5A1A",
    fontSize: 14,
    fontWeight: "800",
    textAlign: "right",
  },
  infoText: {
    color: "#947B4D",
    fontSize: 12,
    lineHeight: 19,
    marginTop: 4,
    textAlign: "right",
  },
  footerText: {
    color: "#A1A39B",
    fontSize: 11,
    marginTop: "auto",
    paddingTop: 28,
    textAlign: "center",
  },
});

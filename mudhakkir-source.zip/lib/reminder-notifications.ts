import AsyncStorage from "@react-native-async-storage/async-storage";
import * as Notifications from "expo-notifications";
import { Platform } from "react-native";

export const REMINDER_INTERVAL_SECONDS = 5 * 60;
export const REMINDER_CHANNEL_ID = "dhikr-reminders";
export const REMINDER_SOUND = "reminder.wav";

const NOTIFICATION_ID_KEY = "dhikr-reminder-notification-id";
const ENABLED_KEY = "dhikr-reminder-enabled";

export function configureReminderNotifications() {
  Notifications.setNotificationHandler({
    handleNotification: async () => ({
      shouldPlaySound: true,
      shouldSetBadge: false,
      shouldShowBanner: true,
      shouldShowList: true,
    }),
  });
}

async function ensurePermission() {
  if (Platform.OS !== "android") {
    throw new Error("الإشعارات الصوتية متاحة في نسخة Android من التطبيق.");
  }

  await Notifications.setNotificationChannelAsync(REMINDER_CHANNEL_ID, {
    name: "تذكيرات الذكر",
    description: "إشعار صوتي متكرر لتذكيرك بذكر الله",
    importance: Notifications.AndroidImportance.HIGH,
    sound: REMINDER_SOUND,
    vibrationPattern: [0, 250, 250, 250],
    lockscreenVisibility: Notifications.AndroidNotificationVisibility.PUBLIC,
  });

  const current = await Notifications.getPermissionsAsync();
  if (current.status === "granted") return;

  const requested = await Notifications.requestPermissionsAsync();
  if (requested.status !== "granted") {
    throw new Error(
      "لم يتم منح إذن الإشعارات. فعّله من إعدادات الهاتف ثم حاول مرة أخرى.",
    );
  }
}

export async function isReminderEnabled() {
  return (await AsyncStorage.getItem(ENABLED_KEY)) === "true";
}

export async function scheduleReminder() {
  await ensurePermission();

  const existingId = await AsyncStorage.getItem(NOTIFICATION_ID_KEY);
  if (existingId) {
    await Notifications.cancelScheduledNotificationAsync(existingId);
  }

  const notificationId = await Notifications.scheduleNotificationAsync({
    content: {
      title: "تذكير لطيف",
      body: "لا تنسى ذكر الله",
      sound: REMINDER_SOUND,
      data: { kind: "dhikr-reminder" },
    },
    trigger: {
      type: Notifications.SchedulableTriggerInputTypes.TIME_INTERVAL,
      channelId: REMINDER_CHANNEL_ID,
      seconds: REMINDER_INTERVAL_SECONDS,
      repeats: true,
    },
  });

  await AsyncStorage.multiSet([
    [NOTIFICATION_ID_KEY, notificationId],
    [ENABLED_KEY, "true"],
  ]);
}

export async function cancelReminder() {
  const notificationId = await AsyncStorage.getItem(NOTIFICATION_ID_KEY);
  if (notificationId) {
    await Notifications.cancelScheduledNotificationAsync(notificationId);
  }

  await AsyncStorage.multiRemove([NOTIFICATION_ID_KEY, ENABLED_KEY]);
}
